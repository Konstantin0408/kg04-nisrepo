interface Prototype {
    fun clone(): Prototype
}