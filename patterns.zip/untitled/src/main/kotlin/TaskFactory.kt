interface TaskFactory {
    fun createTask(description: String, cost: Int) : WorkerTask
}

object DesignTaskFactory : TaskFactory {
    override fun createTask(description: String, cost: Int): WorkerTask = SingularSpecializedTask(
        DesignSpecialization(), description, cost
    )
}

object CodingTaskFactory : TaskFactory {
    override fun createTask(description: String, cost: Int): WorkerTask = SingularSpecializedTask(
        CodingSpecialization(), description, cost
    )
}

object ManagementTaskFactory : TaskFactory {
    override fun createTask(description: String, cost: Int): WorkerTask = SingularSpecializedTask(
        ManagementSpecialization(), description, cost
    )
}

object UniversalTaskFactory : TaskFactory {
    override fun createTask(description: String, cost: Int): WorkerTask = SingularTask(
        description, cost
    )
}