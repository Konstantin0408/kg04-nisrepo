import java.util.Scanner

val scanner = Scanner(System.`in`)

fun readLine(string: String = String()) : String {
    print(string)
    return scanner.nextLine()
}

fun readInt(string: String = String()) : Int {
    print(string)
    return scanner.nextLine().toInt()
}

fun main() {

    val workerFactories = arrayOf(
        DesignWorkerFactory,
        CodingWorkerFactory,
        ManagementWorkerFactory,
        UniversalWorkerFactory,
        UltraHackerFactory
    )
    val taskFactories = arrayOf(
        DesignTaskFactory,
        CodingTaskFactory,
        ManagementTaskFactory,
        UniversalTaskFactory
    )
    val specializations = arrayOf(
        DesignSpecialization(),
        CodingSpecialization(),
        ManagementSpecialization()
    )

    val workers = mutableListOf<Worker>()
    val tasks = mutableListOf<WorkerTask>()
    val publishers = mutableListOf<Publisher>()

    while (true) {
        when (readLine("command: ")) {
            "nw" -> {
                val id = readInt("worker factory id (int): ")
                workers.add(workerFactories[id].createWorker())
                println("New id: ${workers.size - 1}")
            }
            "nt" -> {
                val id = readInt("task factory id (int): ")
                val description = readLine("description: ")
                val cost = readInt("cost (int): ")
                tasks.add(taskFactories[id].createTask(description, cost))
                println("New id: ${tasks.size - 1}")
            }
            "np" -> {
                publishers.add(Publisher())
                println("New id: ${publishers.size - 1}")
            }
            "gt" -> {
                val workerId = readInt("worker id (int): ")
                val taskId = readInt("task id (int): ")
                val worker = workers[workerId]
                val task = tasks[taskId]
                if (worker is PlanningWorker) {
                    if (worker.giveTask(task)) println("OK") else println("Error")
                }
                else println("Not planning worker")
            }
            "dt" -> {
                val workerId = readInt("worker id (int): ")
                val taskId = readInt("task id (int): ")
                val worker = workers[workerId]
                val task = tasks[taskId]
                if (worker.doTask(task)) println("OK") else println("Error")
            }
            "cp" ->  {
                val publisherId = readInt("publisher id (int): ")
                val publisher = publishers[publisherId]
                publishers.add(publisher.clone() as Publisher)
            }
            "sub" -> {
                val publisherId = readInt("publisher id (int): ")
                val workerId = readInt("worker id (int): ")
                val publisher = publishers[publisherId]
                val worker = workers[workerId]
                if (worker is Subscriber) {
                    publisher.addSubscriber(worker)
                    println("OK")
                } else println("Not subscriber")
            }
            "no-gt" -> {
                val publisherId = readInt("publisher id (int): ")
                val publisher = publishers[publisherId]
                val taskId = readInt("task id (int): ")
                val task = tasks[taskId]
                publisher.notifyAllSubscribers(GiveTaskUpdateCommand(task))
            }
            "no-dt" -> {
                val publisherId = readInt("publisher id (int): ")
                val publisher = publishers[publisherId]
                val taskId = readInt("task id (int): ")
                val task = tasks[taskId]
                publisher.notifyAllSubscribers(DoTaskUpdateCommand(task))
            }
            "u2s" -> {
                val workerId = readInt("worker id (int): ")
                val worker = workers[workerId]
                val specializationId = readInt("specialization id (int): ")
                val specialization = specializations[specializationId]
                if (worker is UniversalWorker) {
                    workers.add(UniversalAsSpecializedWorker(specialization, worker))
                    println("New id: ${workers.size - 1}")
                }
                else println("Not universal worker")
            }
            "q" -> {
                break
            }
            else -> {
                println("invalid command")
            }
        }
    }

}