interface Specialization {
    fun identifier() : String
}

class DesignSpecialization : Specialization {
    override fun identifier(): String = "design"
}

class CodingSpecialization : Specialization {
    override fun identifier(): String = "coding"
}

class ManagementSpecialization : Specialization {
    override fun identifier(): String = "management"
}