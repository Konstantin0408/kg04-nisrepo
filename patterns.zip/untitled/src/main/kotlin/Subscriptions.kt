class Publisher: Prototype {
    private var subscribers = mutableListOf<Subscriber>()
    fun notifyAllSubscribers(command: UpdateCommand) = subscribers.forEach {
        subscriber: Subscriber -> subscriber.update(command)
    }

    fun addSubscriber(subscriber: Subscriber) = subscribers.add(subscriber)

    override fun clone(): Prototype {
        val second = Publisher()
        subscribers.forEach { subscriber -> second.subscribers.add(subscriber) }
        return second
    }
}

interface Subscriber {
    fun update(command: UpdateCommand)
}

abstract class UpdateCommand

class DoTaskUpdateCommand(val task: WorkerTask) : UpdateCommand()
class GiveTaskUpdateCommand(val task: WorkerTask) : UpdateCommand()