abstract class Worker {
    abstract fun doTask(task: WorkerTask): Boolean
}

abstract class PlanningWorker : Worker(), Subscriber {
    abstract fun doesTaskFit(task: WorkerTask) : Boolean
    abstract fun isTaskGiven(task: WorkerTask) : Boolean
    abstract fun isTaskCompatible(task: WorkerTask) : Boolean
    abstract fun addTask(task: WorkerTask)
    abstract fun removeTask(task: WorkerTask)

    fun giveTask(task: WorkerTask) : Boolean {
        if (isTaskCompatible(task) && doesTaskFit(task) && !isTaskGiven(task)) {
            addTask(task)
            return true
        }
        return false
    }
    override fun doTask(task: WorkerTask) : Boolean {
        if (isTaskCompatible(task) && isTaskGiven(task)) {
            removeTask(task)
            return true
        }
        return false
    }

    override fun update(command: UpdateCommand) {
        when (command) {
            is DoTaskUpdateCommand -> doTask(command.task)
            is GiveTaskUpdateCommand -> giveTask(command.task)
        }
    }
}

abstract class SpecializedWorker(val specialization: Specialization) : PlanningWorker()

class MultitaskingWorker(
    specialization: Specialization,
    private val maxTasks: Int = 3
) : SpecializedWorker(specialization) {
    private val tasks = mutableSetOf<SpecializedTask>()

    override fun doesTaskFit(task: WorkerTask): Boolean = tasks.size < maxTasks
    override fun isTaskGiven(task: WorkerTask): Boolean = tasks.contains(task)
    override fun isTaskCompatible(task: WorkerTask): Boolean {
        if (task is SpecializedTask) {
            return task.matchesSpecialization(specialization)
        }
        return false
    }
    override fun addTask(task: WorkerTask) {
        tasks.add(task as SpecializedTask)
    }
    override fun removeTask(task: WorkerTask) {
        tasks.remove(task)
    }
}

class UniversalWorker : PlanningWorker() {
    private var optionalTask: WorkerTask? = null

    override fun doesTaskFit(task: WorkerTask): Boolean = optionalTask != null
    override fun isTaskGiven(task: WorkerTask): Boolean = optionalTask == task
    override fun isTaskCompatible(task: WorkerTask): Boolean = true
    override fun addTask(task: WorkerTask) {
        optionalTask = task
    }
    override fun removeTask(task: WorkerTask) {
        optionalTask = null
    }
}

class UniversalAsSpecializedWorker(
    specialization: Specialization,
    private val universalWorker: UniversalWorker
) : SpecializedWorker(specialization) {
    override fun doesTaskFit(task: WorkerTask): Boolean = universalWorker.doesTaskFit(task)
    override fun isTaskGiven(task: WorkerTask): Boolean = universalWorker.isTaskGiven(task)
    override fun isTaskCompatible(task: WorkerTask): Boolean = universalWorker.isTaskGiven(task)
    override fun addTask(task: WorkerTask) = universalWorker.addTask(task)
    override fun removeTask(task: WorkerTask) = universalWorker.removeTask(task)
}