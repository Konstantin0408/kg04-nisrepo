interface WorkerTask {
    fun taskDescription(): String
    fun taskCost(): Int
}

interface SpecializedTask : WorkerTask {
    fun taskSpecialization(): Specialization
    fun matchesSpecialization(specialization: Specialization) : Boolean
}

class SingularTask(
    private val description: String,
    private val cost: Int
) : WorkerTask {
    override fun taskDescription(): String = description
    override fun taskCost(): Int = cost
}


class SingularSpecializedTask(
    private val specialization: Specialization,
    private val description: String,
    private val cost: Int
) : SpecializedTask {
    override fun taskDescription(): String = description
    override fun taskCost(): Int = cost
    override fun taskSpecialization(): Specialization = specialization
    override fun matchesSpecialization(specialization: Specialization) : Boolean {
        return this.specialization.identifier() == specialization.identifier()
    }
}

class CompositeTask(
    private val description: String,
    private val cost: Int,
    private val daughterTasks: Iterable<WorkerTask>
) : WorkerTask {
    //fun primaryDescription(): String = description
    //fun primaryCost(): Int = cost
    override fun taskDescription(): String = "$description: [ ${daughterTasks.fold(
        initial = String(), 
        operation = { acc, workerTask ->  
            "$acc${workerTask.taskDescription()} "
        }
    )
    }]"
    override fun taskCost(): Int = cost + daughterTasks.fold(
        initial = 0,
        operation = { acc, workerTask ->
            acc+ workerTask.taskCost()
        }
    )
}
