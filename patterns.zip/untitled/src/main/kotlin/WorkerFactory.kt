interface WorkerFactory {
    fun createWorker() : Worker
}

object DesignWorkerFactory : WorkerFactory {
    override fun createWorker(): Worker = MultitaskingWorker(DesignSpecialization())
}

object CodingWorkerFactory : WorkerFactory {
    override fun createWorker(): Worker = MultitaskingWorker(CodingSpecialization())
}

object ManagementWorkerFactory : WorkerFactory {
    override fun createWorker(): Worker = MultitaskingWorker(ManagementSpecialization())
}

object UniversalWorkerFactory : WorkerFactory {
    override fun createWorker(): Worker = UniversalWorker()
}

object UltraHackerFactory : WorkerFactory {
    override fun createWorker(): Worker = MultitaskingWorker(CodingSpecialization(), 10)
}
