//
//  AboutViewController.swift
//  gl1
//
//  Created by MacBook Pro  on 15.03.24.
//

import MapKit
import SwiftUI
import CoreLocation

class AboutViewController: UIViewController {
    public weak var viewController: UIViewController? = nil
    
    let titleLabel = UILabel()
    
    let emailLabel = UILabel()
    let emailLabel2 = UILabel()
    let telegramLabel = UILabel()
    
    let map = MKMapView()
    
    public static let contactSize = CGFloat(18)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        configureTitle()
        configureEmail()
        configureCorporateEmail()
        configureTelegram()
        configureUniPin()
    }
    
    func makeText(label: UILabel, text: String) {
        label.text = text
        label.textAlignment = .center
        label.textColor = .black
    }
    
    
    func configureTitle() {
        self.view.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 60),
        ])
        titleLabel.font = .boldSystemFont(ofSize: 30)
        makeText(label: titleLabel, text: "About")
    }
    
    func configureEmail() {
        self.view.addSubview(emailLabel)
        emailLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            emailLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emailLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
        ])
        emailLabel.font = .systemFont(ofSize: AboutViewController.contactSize)
        makeText(label: emailLabel, text: "Email: k.gogrichiani04@bk.ru")
    }
    
    func configureCorporateEmail() {
        self.view.addSubview(emailLabel2)
        emailLabel2.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            emailLabel2.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emailLabel2.topAnchor.constraint(equalTo: emailLabel.bottomAnchor, constant: 10),
        ])
        emailLabel2.font = .systemFont(ofSize: AboutViewController.contactSize)
        makeText(label: emailLabel2, text: "Corporate mail: kggogrichiani_1@edu.hse.ru")
    }
    
    func configureTelegram() {
        self.view.addSubview(telegramLabel)
        telegramLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            telegramLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            telegramLabel.topAnchor.constraint(equalTo: emailLabel2.bottomAnchor, constant: 10),
        ])
        telegramLabel.font = .systemFont(ofSize: AboutViewController.contactSize)
        makeText(label: telegramLabel, text: "Telegram: konstanting04")
    }
    
    func configureUniPin() {
        self.view.addSubview(map)
        map.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            map.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -50),
            map.topAnchor.constraint(equalTo: view.centerYAnchor, constant: 10),
            map.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            map.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0)
        ])
        
        let pin = MKPointAnnotation()
        let location = CLLocation(latitude: 55.753607, longitude: 37.649046)
        pin.coordinate = location.coordinate
        map.setRegion(MKCoordinateRegion(
            center: location.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        ), animated: true)
        map.addAnnotation(pin)
    }
    
}
