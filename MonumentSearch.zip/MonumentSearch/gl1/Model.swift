//
//  Feature.swift
//  gl1
//
//  Created by MacBook Pro  on 14.03.24.
//

import Foundation
import _MapKit_SwiftUI

class Feature : Decodable {
    public let properties: FeatureProperties?
}

class FeatureCollection : Decodable {
    public let features: Array<Feature>?
}

class FeatureProperties : Decodable {
    public let lon: Double?
    public let lat: Double?
    public let formatted: String?
    public let wiki_and_media: Dictionary<String, String>?
}

class ArticleInfo : Decodable {
    class ArticleInfoQuery : Decodable {
        public let pages: Dictionary<String, PageInfo>?
        class PageInfo : Decodable {
            public let revisions: Array<Dictionary<String, String>>?
            public let extract: String?
        }
    }
    public let query : ArticleInfoQuery?
}


