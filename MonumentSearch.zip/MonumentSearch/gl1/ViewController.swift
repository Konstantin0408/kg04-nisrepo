//
//  ViewController.swift
//  gl1
//
//  Created by MacBook Pro  on 06.03.24.
//

import MapKit
import UIKit
import CoreLocation
import Foundation
import AVFoundation
import SwiftUI

class ViewController: UIViewController {
    
    public let synth = AVSpeechSynthesizer()
    var myUtterance = AVSpeechUtterance(string: "Hello speech")
    
    let viewModel = ViewModel()
    
    static let geoCoder = CLGeocoder()
    var navState = NavigationState.userLocation
    let locationManager: CLLocationManager?
    let map = MKMapView()
    
    let field: UITextField = UITextField()
    @IBOutlet var button: UIButton! = UIButton()
    let showSelfButton: UIButton = UIButton()
    let muteButton: UIButton = UIButton()
    
    let routes: UIStackView = UIStackView()
    
    var currentLocation: CLLocation?
    var selectedLocation: CLLocation?
    
    let aboutButton: UIButton = UIButton()
    let settingsButton: UIButton = UIButton()
    let aboutScreen = AboutViewController()
    let settingsScreen = SettingsViewController()
    
    public let speechRate = 0.3
    
    var features: Array<Feature> = Array()
    
    var routesViews: Array<UIView> = Array()

    override func viewDidLoad() {
        super.viewDidLoad()
        aboutScreen.viewController = self
        settingsScreen.viewController = self
        
        configureMap()
        
        configureTextField()
        configureSearchButton()
        configureStackView()
        configureShowSelfButton()
        configureMuteButton()
        
        configureAboutButton()
        configureSettingsButton()
        
        LocationManager.shared.getUserLocation { [weak self] location in
            DispatchQueue.main.async {
                guard let strongSelf = self else {
                    return
                }
                strongSelf.addMapPin(with: location)
            }
        }
        
        locationManager?.delegate = self
        locationManager?.requestAlwaysAuthorization()
        
        // Do any additional setup after loading the view.
    }
    
    func roundCorners(view: UIView) {
        view.layer.cornerRadius = 4
    }
    
    func configureMap() {
        view.addSubview(map)
        map.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            map.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            map.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 1/3),
            map.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            map.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0)
        ])
    }
    
    func configureTextField() {
        view.addSubview(field)
        roundCorners(view: field)
        field.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            field.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0),
            field.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -60),
            field.heightAnchor.constraint(equalToConstant: 30),
            field.widthAnchor.constraint(equalToConstant: 180)
        ])
        field.backgroundColor = .lightGray
        
    }
    
    func configureShowSelfButton() {
        view.addSubview(showSelfButton)
        roundCorners(view: showSelfButton)
        showSelfButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            showSelfButton.topAnchor.constraint(equalTo: map.bottomAnchor, constant: 10),
            showSelfButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            showSelfButton.heightAnchor.constraint(equalToConstant: 30),
            showSelfButton.widthAnchor.constraint(equalToConstant: 100)
        ])
        showSelfButton.backgroundColor = .systemCyan
        showSelfButton.setTitle("Show self", for: .normal)
        showSelfButton.addTarget(self, action: #selector(showSelfButtonPressed), for: .touchUpInside)
    }
    
    func configureMuteButton() {
        view.addSubview(muteButton)
        roundCorners(view: muteButton)
        muteButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            muteButton.topAnchor.constraint(equalTo: showSelfButton.bottomAnchor, constant: 5),
            muteButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            muteButton.heightAnchor.constraint(equalToConstant: 30),
            muteButton.widthAnchor.constraint(equalToConstant: 100)
        ])
        muteButton.backgroundColor = .red
        muteButton.setTitle("Mute", for: .normal)
        muteButton.addTarget(self, action: #selector(muteButtonPressed), for: .touchUpInside)
    }
    
    func configureSearchButton() {
        view.addSubview(button)
        roundCorners(view: button)
        button.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            button.centerYAnchor.constraint(equalTo: field.centerYAnchor, constant: 0),
            button.leadingAnchor.constraint(equalTo: field.trailingAnchor, constant: 10),
            button.heightAnchor.constraint(equalToConstant: 30),
            button.widthAnchor.constraint(equalToConstant: 100)
        ])
        button.backgroundColor = .systemCyan
        button.setTitle("Search", for: .normal)
        button.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
    }
    
    func configureAboutButton() {
        view.addSubview(aboutButton)
        roundCorners(view: aboutButton)
        aboutButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            aboutButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            aboutButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            aboutButton.heightAnchor.constraint(equalToConstant: 50),
            aboutButton.widthAnchor.constraint(equalToConstant: 100)
        ])
        aboutButton.backgroundColor = .lightGray
        aboutButton.setTitle("About", for: .normal)
        aboutButton.addTarget(self, action: #selector(aboutButtonClicked), for: .touchUpInside)
    }
    
    func configureSettingsButton() {
        view.addSubview(settingsButton)
        roundCorners(view: settingsButton)
        settingsButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            settingsButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            settingsButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            settingsButton.heightAnchor.constraint(equalToConstant: 50),
            settingsButton.widthAnchor.constraint(equalToConstant: 100)
        ])
        settingsButton.backgroundColor = .lightGray
        settingsButton.setTitle("Settings", for: .normal)
        settingsButton.addTarget(self, action: #selector(settingsButtonClicked), for: .touchUpInside)
    }
    
    func configureStackView() {
        view.addSubview(routes)
        routes.axis = .vertical
        routes.alignment = .leading
        routes.distribution = .fillEqually
        routes.spacing = 10
        
        routes.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            routes.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -60),
            routes.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 1/3),
            routes.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            routes.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0)
        ])
        
        for routeView in routesViews {
            self.routes.addArrangedSubview(routeView)
        }
        
    }
    
    @IBAction func showSelfButtonPressed(_ sender: UIButton) {
        if currentLocation == nil { return }
        navState = .userLocation
        addMapPin(with: currentLocation!)
    }
    
    @IBAction func muteButtonPressed(_ sender: UIButton) {
        synth.stopSpeaking(at: .immediate)
    }
    
    @IBAction func selectButtonClicked(_ sender: UIButton) {
        let index = Int((sender.layer.name)!)!
        let feature = features[index]
        print((feature.properties?.formatted)!)
        navState = .selectedLocation(feature)
        let lat = (feature.properties?.lat)!
        let lon = (feature.properties?.lon)!
        addMapPin(with: CLLocation(latitude: lat, longitude: lon))
    }
    
    @IBAction func infoButtonClicked(_ sender: UIButton) {
        let index = Int((sender.layer.name)!)! - 100
        let feature = features[index]
        if let media = feature.properties?.wiki_and_media {
            if let wikiLink = media["wikipedia"] {
                let info = viewModel.getInfo(title: wikiLink)!
                let pages = info.query?.pages
                let firstPage = pages?.first
                //let fullText = firstPage?.value.revisions?.first?["*"]
                let fullText = (firstPage?.value.extract)!
                myUtterance = AVSpeechUtterance(string: fullText)
                synth.speak(myUtterance)
            }
        }
    }
    
    @IBAction func buttonClicked(_ sender: Any) {
        print(field.text!)
        
        if currentLocation == nil {
            print("no location")
            return
        }
        
        for routeView in self.routesViews {
            self.routes.removeArrangedSubview(routeView)
            routeView.removeFromSuperview()
        }
        self.routesViews.removeAll()
        self.features.removeAll()
        
        let lon = (currentLocation?.coordinate.longitude)!
        let lat = (currentLocation?.coordinate.latitude)!
        let name = field.text!
        
        button.setTitle("Wait...", for: .normal) //...
        print("AU")
        button.isEnabled = false
        
        if let featureCol = viewModel.getRoutes(lon: lon, lat: lat, name: name) {
            var index = 0
            for feature in featureCol.features! {
                let newView = UIView()
                newView.translatesAutoresizingMaskIntoConstraints = false
                
                
                let label = UILabel()
                label.text = feature.properties?.formatted
                newView.addSubview(label)
                label.translatesAutoresizingMaskIntoConstraints = false
                
                let selectButton = UIButton()
                roundCorners(view: selectButton)
                selectButton.setTitle("Select", for: .normal)
                newView.addSubview(selectButton)
                selectButton.translatesAutoresizingMaskIntoConstraints = false
                selectButton.backgroundColor = .green
                selectButton.layer.name = "\(index)"
                selectButton.addTarget(self, action: #selector(selectButtonClicked), for: .touchUpInside)
                
                
                routesViews.append(newView)
                self.routes.addArrangedSubview(newView)
                
                NSLayoutConstraint.activate([
                    newView.leadingAnchor.constraint(equalTo: routes.leadingAnchor, constant: 2),
                    newView.trailingAnchor.constraint(equalTo: routes.trailingAnchor, constant: -2),
                    
                    label.leadingAnchor.constraint(equalTo: newView.leadingAnchor, constant: 5),
                    label.widthAnchor.constraint(equalToConstant: 200),
                    
                    selectButton.leadingAnchor.constraint(equalTo: label.trailingAnchor, constant: 10),
                    selectButton.widthAnchor.constraint(equalToConstant: 70),
                    selectButton.heightAnchor.constraint(equalToConstant: 20)
                ])
                
                if feature.properties?.wiki_and_media?["wikipedia"] != nil
                {
                    let infoButton = UIButton()
                    roundCorners(view: infoButton)
                    infoButton.setTitle("Info", for: .normal)
                    newView.addSubview(infoButton)
                    infoButton.translatesAutoresizingMaskIntoConstraints = false
                    infoButton.backgroundColor = .systemPink
                    infoButton.layer.name = "\(index + 100)"
                    infoButton.addTarget(self, action: #selector(infoButtonClicked), for: .touchUpInside)
                    
                    NSLayoutConstraint.activate([
                        infoButton.leadingAnchor.constraint(equalTo: selectButton.trailingAnchor, constant: 10),
                        infoButton.widthAnchor.constraint(equalToConstant: 60),
                        infoButton.heightAnchor.constraint(equalToConstant: 20)
                    ])
                }
                
                features.append(feature)
                
                index += 1
            }
        }
        else {
            print("none")
        }
        button.isEnabled = true
        button.setTitle("Search", for: .normal)
        
    }
    
    @IBAction func aboutButtonClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        self.present(aboutScreen, animated: true, completion: nil)
    }
    
    @IBAction func settingsButtonClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        self.present(settingsScreen, animated: true, completion: nil)
    }
    
    required init?(coder: NSCoder) {
        self.locationManager = CLLocationManager()
        super.init(coder: coder)
    }
    
    func addMapPin(with location: CLLocation) {
        let pin = MKPointAnnotation()
        pin.coordinate = location.coordinate
        map.setRegion(MKCoordinateRegion(
            center: location.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        ), animated: true)
        map.addAnnotation(pin)
        
        LocationManager.shared.resolveLocationName(with: location) { [weak self] locationName in
            self?.title = locationName
        }
    }

}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            switch navState {
            case .userLocation:
                addMapPin(with: location)
            default:
                _ = 0
            }
            
            currentLocation = location
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager?.startUpdatingLocation()
        }
    }
}

