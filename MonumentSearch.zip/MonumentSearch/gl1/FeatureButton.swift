//
//  FeatureButton.swift
//  gl1
//
//  Created by MacBook Pro  on 15.03.24.
//

import Foundation
import UIKit

class FeatureButton {
    public let button: UIButton
    public let feature: Feature
    
    init(button: UIButton, feature: Feature) {
        self.button = button
        self.feature = feature
    }
}
