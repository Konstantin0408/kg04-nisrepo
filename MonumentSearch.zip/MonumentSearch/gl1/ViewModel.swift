//
//  ViewModel.swift
//  gl1
//
//  Created by MacBook Pro  on 15.03.24.
//

import Foundation

class ViewModel : NSObject {
    func getRoutes(lon: Double, lat: Double, name: String) -> FeatureCollection? {
        var featureCollection: FeatureCollection?
        
        let urlString = "https://api.geoapify.com/v2/places?categories=tourism&name=\(name)&filter=circle:\(lon),\(lat),50000&limit=5&apiKey=622b7d632401412993e3c5826a787d73".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        print(urlString)
        let url = URL(string: urlString)
        let task = URLSession.shared.dataTask(with: url as! URL) { data, response, error in
            if (data != nil) {
                featureCollection = try! JSONDecoder().decode(FeatureCollection.self, from: data!)
            }
        }
        
        task.resume()
        while (featureCollection == nil) { }
        return featureCollection
    }
    
    func getInfo(title: String) -> ArticleInfo? {
        var info: ArticleInfo? = nil
        //let urlString = "https://en.wikipedia.org/w/api.php?action=query&prop=revisions&rvprop=content&rvsection=0&titles=\(title)&format=json".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let urlString = "https://ru.wikipedia.org/w/api.php?action=query&prop=extracts&exlimit=1&titles=\(title)&explaintext=1&exsectionformat=plain&format=json".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        print(urlString)
        let url = URL(string: urlString)
        let task = URLSession.shared.dataTask(with: url as! URL) { data, response, error in
            if (data != nil) {
                info = try! JSONDecoder().decode(ArticleInfo.self, from: data!)
            }
        }
        task.resume()
        while (info == nil) { }
        return info
    }
}
