//
//  SettingsViewController.swift
//  gl1
//
//  Created by MacBook Pro  on 15.03.24.
//

import SwiftUI
import Foundation


class SettingsViewController: UIViewController {
    let titleLabel = UILabel()
    
    let brightnessLabel = UILabel()
    let slider = UISlider()
    
    let speedLabel = UILabel()
    let speedSlider = UISlider()
    
    public weak var viewController: UIViewController? = nil
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        configureTitle()
        configureBrightnessLabel()
        configureSlider()
        //configureSpeedLabel()
        //configureSpeedSlider()
    }
    
    func makeText(label: UILabel, text: String) {
        label.text = text
        label.textAlignment = .center
        label.textColor = .black
    }
    
    
    func configureTitle() {
        self.view.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 60),
        ])
        titleLabel.font = .boldSystemFont(ofSize: 30)
        makeText(label: titleLabel, text: "Settings")
    }
    
    @IBAction func changeBackgroundColor(_ sender: UISlider) {
        view.backgroundColor = UIColor(white: CGFloat(1 - sender.value * 0.75), alpha: 1)
        viewController?.view.backgroundColor = UIColor(white: CGFloat(1 - sender.value * 0.75), alpha: 1)
    }
    
    @IBAction func changeSpeed(_ sender: UISlider) {
        
    }
    
    func configureBrightnessLabel() {
        self.view.addSubview(brightnessLabel)
        brightnessLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            brightnessLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            brightnessLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 30),
        ])
        brightnessLabel.font = .systemFont(ofSize: AboutViewController.contactSize)
        makeText(label: brightnessLabel, text: "Screen shade")
    }
    
    func configureSlider() {
        self.view.addSubview(slider)
        slider.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            slider.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            slider.topAnchor.constraint(equalTo: brightnessLabel.bottomAnchor, constant: 15),
            slider.widthAnchor.constraint(equalToConstant: 300)
        ])
        slider.addTarget(self, action: #selector(changeBackgroundColor), for: .valueChanged)
    }
    
    
    func configureSpeedLabel() {
        self.view.addSubview(speedLabel)
        speedLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            speedLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            speedLabel.topAnchor.constraint(equalTo: slider.bottomAnchor, constant: 30),
        ])
        speedLabel.font = .systemFont(ofSize: AboutViewController.contactSize)
        makeText(label: speedLabel, text: "Speech rate")
    }
    
    func configureSpeedSlider() {
        self.view.addSubview(speedSlider)
        speedSlider.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            speedSlider.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            speedSlider.topAnchor.constraint(equalTo: speedLabel.bottomAnchor, constant: 15),
            speedSlider.widthAnchor.constraint(equalToConstant: 300)
        ])
        speedSlider.addTarget(self, action: #selector(changeBackgroundColor), for: .valueChanged)
    }
    
    
}
