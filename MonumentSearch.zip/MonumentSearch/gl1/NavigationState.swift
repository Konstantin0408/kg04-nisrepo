//
//  NavigationState.swift
//  gl1
//
//  Created by MacBook Pro  on 15.03.24.
//

import Foundation

enum NavigationState {
    case userLocation
    case selectedLocation(Feature)
    case emulatedLocation(Double, Double)
}
